#include <stdio.h>
#include <math.h>

/* wav.txt の行数 */
#define N 37800

/* ir.txt の行数 */ 
#define M 32748

/* pianoir.txt の行数 */ 
//#define M 31684

int main(){
FILE *file;
FILE *irfile;

int i,j;
int tmp;
int data;
double data1[N];
double data2[M];
double conv[N+M];
double res;

file = fopen("wav.txt", "r");
//irfile = fopen("pianoir.txt", "r");
irfile = fopen("ir.txt", "r");

for(i=0;i<N;i++){
    fscanf(file , "%d" , &data);
    data1[i] = (double)data;
}

for(i=0;i<M;i++){
    fscanf(irfile , "%d" , &data);
    data2[i] = (double)data;
}

for(i=0;i<N+M;i++){
    res = 0;
    for(j=0;j<i;j++){
        if(i-j<M && j<N) {
            res = res+data1[j]*data2[i-j];
        }
    }
    conv[i] = res;
}

file = fopen("data.txt", "w");
for(i=0;i<N+M;i++){
  fprintf(file, "%lf \n", conv[i]);
}
fclose(file);
return 0;
}
