# テキストデータを音声ファイルに変換するプログラム

import wave
import struct
import csv
import numpy as np

w = wave.open("input.wav",mode='r')
print(w.getframerate())
num_data = w.getnframes()
if w.getsampwidth() == 2:
    buf = np.frombuffer(w.readframes(-1), dtype='int16')
elif w.getsampwidth() > 2:
    buf = np.frombuffer(w.readframes(-1), dtype='int32')

#buf = np.frombuffer(w.readframes(-1), dtype='float')
print(buf)
np.savetxt('ir.txt',buf,fmt='%d')

w.close()
